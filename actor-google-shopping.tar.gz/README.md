# Google Shopping Scraper
Google Shopping Scraper is an [Apify actor](https://apify.com/actors) for extracting data from [Google Shopping](https://www.google.com/shopping) web site.
It scrapes the first result page and details about each product and its sellers.

- [Input](#input)
- [Output](#output)
- [Authorization](#authorization)
- [Extend output function](#extend-output-function)
- [Open an issue](#open-an-issue)

### Input

| Field | Type | Description |
| ----- | ---- | ----------- |
| queries | Array of Strings | List of queries to search for |
| countryCode | String | Country selected from enum (value is ISO-3166 Alpha-2 country code) |

Uses the provided configuration to look up product on google shopping and then use the first result to go
to the list of sellers. Then it scrapes all sellers and outputs following result:

```json
{
  "query": "08130085",
  "GTIN": "08130085",
  "shoppingId": "18082572037978846938",
  "shoppingUrl": "https://www.google.dk/shopping/product/18082572037978846938",
  "sellerCount": 1,
  "sellers": [
    {
      "seller": "Outnorth.se",
      "link": "https://www.google.dk/aclk?sa=l&ai=DChcSEwjjqdGenKvlAhUOboYKHeBmABUYABABGgJ2dQ&sig=AOD64_1cHeyblcuwTU7Poomy02TulrLLoQ&adurl=&ctype=5&q=",
      "rating": "95 % positiv",
      "ratingCount": 365,
      "details": "",
      "price": "385,00 SEK",
      "totalPrice": "434,00 SEK",
      "additionalPrice": "Forsendelse"
    },
  ],
}
```
