const REQUEST_TYPES = {
    PRODUCT_PAGE: 'PRODUCT_PAGE',
    SEARCH_PAGE: 'SEARCH_PAGE',
};

module.exports = {
    REQUEST_TYPES,
};
